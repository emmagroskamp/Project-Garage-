<html>
    <head><title>De blije hond</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css"
        integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
        <link rel="stylesheet" type="text/css" href="deblijehond.css">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
    <div class="left">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="homepagina.php"> De blije hond</a>
        <ul class="navbar-nav">
            <li class="nav-item active">
                <a class="nav-link" href="homepagina.php">Home<span class="sr-only"></span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="klant_aanmaken.php">Nieuwe klant</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="klant_overzicht.php">Klant overzicht</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="overzicht_product.php">Overzicht producten</a>
            </li>
        </ul>
    </nav>
    </div>
    <!--Code voor de navigatiebalk bovenin de webpagina.-->

    <div class="main">
    <div class="jumbotron jumbotron-fluid">
        <div class="honden">
        <br><br><br><br><br>
        <br><br><br><br><br>
        <br><br><br><br><br>
        <br><br><br><br><br>
        <br><br><br><br><br>
        <br><br><br><br><br>
        <br><br><br><br><br>
        </div>
    </div>
        <!--Divider voor background-image van honden.-->

        <div class="row">
        <div class="col-12">
            <p style="text-align: center;">© de blije hond - 2023</p>
        </div>
    </div>
    <div class="right">
    </div>
    </body>
</html>